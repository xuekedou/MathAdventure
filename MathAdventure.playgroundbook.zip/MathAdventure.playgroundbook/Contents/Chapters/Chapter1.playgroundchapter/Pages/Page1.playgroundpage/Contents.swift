/*:
 # 目标：通过钓鱼的方式找出等式右边的正确答案
 * 点击游戏界面的任何地方开始钓鱼，只要鱼钩碰到小鱼，就能够把小鱼钓起来，并且等式右边的数值会等于小鱼背上的数值。
 * 等式成立，数值[变绿](glossary://变绿)，立即进入下一题；等式不成立，数值[变红](glossary://变红)，消耗一次容错次数并且继续找本题目的答案。
 * 每个关卡有三个等式，找出三个等式的答案之后即可进入下一个关卡。
 * 你可以自定义[容错次数](glossary://容错次数)来调整关卡的难度哦~
 
 # 🎉 非常棒，你现在了解了游戏的基本规则，开始你的数学之旅吧！
 */
//#-hidden-code
import UIKit
import SpriteKit
import GameplayKit
import PlaygroundSupport
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let scene = GameScene(size: CGSize(width: 320, height: 480))
scene.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
scene.physicsBody = SKPhysicsBody(edgeLoopFrom: scene.frame)
sceneView.presentScene(scene)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
//自定义容错次数
//#-code-completion(everything, hide)
scene.lives = /*#-editable-code*/2/*#-end-editable-code*/


