/*:
 🎉 非常棒，你已经认识了加法运算符、减法运算符和乘法运算符，接下来你将学习四个数学基本运算符中的最后一个运算符——除法运算符！
 # 目标：通过钓鱼的方式找出等式右边的正确答案
 * 注意比较除法运算符和其他三种运算符之间的区别和联系哦~
 
 🎉 非常棒，你已经认识了[数学中四个基本的运算符](glossary://数学中四个基本的运算符)，在接下来的章节中，你会更好的掌握它们。
 */
//#-hidden-code
import UIKit
import SpriteKit
import GameplayKit
import PlaygroundSupport


let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let scene = GameSceneFour(size: CGSize(width: 320, height: 480))
scene.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
scene.physicsBody = SKPhysicsBody(edgeLoopFrom: scene.frame)
sceneView.presentScene(scene)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
//自定义容错次数
//#-code-completion(everything, hide)
scene.lives = /*#-editable-code*/2/*#-end-editable-code*/
