//
//  GameSceneTwo.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/19.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit
import GameplayKit
import PlaygroundSupport

public class GameSceneEleven: SKScene,SKPhysicsContactDelegate {
    
    let background = BackgroundNode()
    let person = PersonNode.NewInstance()
    let rope = RopeNode.newInstance()
    let hook = HookNode.newInstance()
    var cropNode = SKCropNode()
    var maskNode = SKSpriteNode()
    var calBackground = SKSpriteNode()
    var times = SKSpriteNode()
    var fish : GoldenNode!
    var addCurrentNumber : Int = 0
    var addNumberOne : Int = 0
    var addNumberTwo : Int = 0
    var numberOneLabel : SKLabelNode!
    var operatOneLabel : SKLabelNode!
    var numberTwoLabel : SKLabelNode!
    var operatTwoLabel : SKLabelNode!
    var numberThreeLabel : SKLabelNode!
    var resultDefine : SKLabelNode!
    var livesLabel : SKLabelNode!
    public var lives : Int = 4
    var isContact : Bool = false
    var currentLevel : Int = 1
    var currentResult : Int = 3
    var numberArray = [Int]()
    //结果数字
    var numberThree : Int = 8
    var numberPosition : Int = 1
    override public func didMove(to view: SKView) {
        super.didMove(to: view)
        playBackgroundMusic(fileName: "background.wav", loops: -1)
        //背景
        background.setup(size: size)
        addChild(background)
        //人
        person.position = CGPoint(x: size.width/2, y: size.height/2 + person.size.height/8*3)
        addChild(person)
        rope.position.x = -person.frame.size.width/14
        rope.position.y = person.frame.height/6 + rope.size.height/4
        hook.position.x = 2
        hook.position.y = -rope.size.height/2 - 5
        rope.addChild(hook)
        maskNode = SKSpriteNode(color: .white, size: CGSize(width: size.width, height: size.height/2 - person.size.height/10))
        maskNode.anchorPoint = CGPoint(x: 0.5, y: 0)
        maskNode.position = CGPoint(x: 0, y: -(person.frame.size.height/8*3 + size.height/2))
        maskNode.zPosition = 2
        cropNode.maskNode = maskNode
        cropNode.addChild(rope)
        cropNode.name = "crop"
        cropNode.zPosition = 2
        person.addChild(cropNode)
        person.moveRepeat(size: size)
        spawnFishes()
        setOperate()
    }
    func setOperate(){
        calBackground = SKSpriteNode(texture: SKTexture(imageNamed: "shiziBackground"))
        calBackground.physicsBody?.isDynamic = false
        calBackground.size = CGSize(width: calBackground.size.width/2,height: calBackground.size.height/2)
        calBackground.position = CGPoint(x: calBackground.size.width/2 + 10, y: size.height - calBackground.size.height/2 - 10)
        addChild(calBackground)
        //第一个数字
        numberOneLabel = SKLabelNode()
        numberOneLabel.text = " "
        numberOneLabel.position = CGPoint(x: calBackground.frame.minX + 40, y: size.height/8*7)
        numberOneLabel.physicsBody?.isDynamic = false
        numberOneLabel.zPosition = 10
        numberOneLabel.fontColor = UIColor.white
        numberOneLabel.fontName = "宋体"
        addChild(numberOneLabel)
        //第一个运算符
        operatOneLabel = SKLabelNode()
        operatOneLabel.text = "X"
        operatOneLabel.position = CGPoint(x: numberOneLabel.frame.maxX + 20, y: size.height/8*7)
        operatOneLabel.physicsBody?.isDynamic = false
        operatOneLabel.zPosition = 10
        operatOneLabel.fontColor = UIColor.white
        operatOneLabel.fontName = "宋体"
        addChild(operatOneLabel)
        //第二个数字
        numberTwoLabel = SKLabelNode()
        numberTwoLabel.text = " "
        numberTwoLabel.position = CGPoint(x: operatOneLabel.frame.maxX + 20 , y: size.height/8*7)
        numberTwoLabel.physicsBody?.isDynamic = false
        numberTwoLabel.zPosition = 10
        numberTwoLabel.fontColor = UIColor.white
        numberTwoLabel.fontName = "宋体"
        addChild(numberTwoLabel)
        //第er个运算符
        operatTwoLabel = SKLabelNode()
        operatTwoLabel.text = "="
        operatTwoLabel.position = CGPoint(x: numberTwoLabel.frame.maxX + 20, y: size.height/8*7)
        operatTwoLabel.physicsBody?.isDynamic = false
        operatTwoLabel.zPosition = 10
        operatTwoLabel.fontColor = UIColor.white
        operatTwoLabel.fontName = "宋体"
        addChild(operatTwoLabel)
        //结果label
        numberThreeLabel = SKLabelNode()
        numberThreeLabel.text = "\(numberThree)"
        numberThreeLabel.position = CGPoint(x: operatTwoLabel.frame.maxX + 20, y: size.height/8*7)
        numberThreeLabel.physicsBody?.isDynamic = false
        numberThreeLabel.zPosition = 10
        numberThreeLabel.fontColor = UIColor.white
        numberThreeLabel.fontName = "宋体"
        addChild(numberThreeLabel)
        //结果判断的label
        resultDefine = SKLabelNode()
        resultDefine.text = " "
        resultDefine.position = CGPoint(x: numberThreeLabel.frame.maxX + 100, y: size.height/8*7)
        resultDefine.fontColor = UIColor.red
        resultDefine.physicsBody?.isDynamic = false
        resultDefine.zPosition = 10
        addChild(resultDefine)
        
        times = SKSpriteNode(texture: SKTexture(imageNamed: "times"))
        times.physicsBody?.isDynamic = false
        times.size = CGSize(width: times.size.width/4,height: times.size.height/4)
        times.position = CGPoint(x: size.width - times.size.width/2 - 10, y: size.height - times.size.height/2 - 10)
        addChild(times)
        //剩余生命次数
        livesLabel = SKLabelNode()
        livesLabel.text = "\(lives)"
        livesLabel.position = CGPoint(x: -2, y: -10)
        livesLabel.fontColor = UIColor.white
        livesLabel.physicsBody?.isDynamic = false
        livesLabel.zPosition = 10
        livesLabel.fontName = "宋体"
        times.addChild(livesLabel)
    }
    override public func sceneDidLoad() {
        self.physicsWorld.contactDelegate = self
    }
    func spawnFishes(){
        //数字是2,4,3,8,5,14
        numberArray = [2,4,3,8,5,14]
        for var i in 0...5{
            let j = numberArray[i]
            fish = GoldenNode.NewInstance(tag: j)
            let fishX = CGFloat.random(min: -fish.size.width/2,max: size.width + fish.size.width/2)
            let rateHight = (size.height/2 - fish.size.height)/6
            if i == 0{
                i = 4
            }else if i == 4{
                i = 0
            }
            let fishY = CGFloat(fish.size.height/2 + rateHight*CGFloat(5-i))
            let fishSpeed = CGFloat.random(min: 4.0,max: 6.0)
            fish.position = CGPoint(x: fishX, y: fishY)
            fish.moveRepeat(size: size, tag : j,speed : fishSpeed)
            addChild(fish)
        }
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        isUserInteractionEnabled = false
        print("person")
        let Y = rope.moveDownY(offset: -(person.frame.size.height/8*3 + size.height/2)+rope.size.height/2)
        playSoundEffect(fileName: "fangxian.wav", loops: 0)
        let Y1 = rope.moveUpY(offset: person.frame.height/6 + rope.size.height/4, time: 1.0)
        rope.run(Y){
            self.rope.run(Y1){
                self.isUserInteractionEnabled = true
            }
        }
    }
    
    
    public func didBegin(_ contact: SKPhysicsContact){
        if (contact.bodyA.categoryBitMask == HookCategory && contact.bodyB.categoryBitMask == GoldenCategory) {
            if !isContact{
                isContact = true
                let fishRemove = contact.bodyB.node!
                let fishID = fishRemove.name
                addCurrentNumber = Int(fishID!)!
                let hookContact = contact.bodyA.node!
                hookContact.physicsBody?.contactTestBitMask = 0
                fishRemove.removeAllActions()
                rope.removeAllActions()
                fishRemove.move(toParent: hookContact)
                fishRemove.position = CGPoint(x: 0, y: -hookContact.frame.size.height/2)
                print("c")
                let ropeReset = rope.moveUpY(offset: person.frame.height/6 + rope.size.height/4, time: 1)
                rope.run(ropeReset){
                    fishRemove.removeFromParent()
                    self.isUserInteractionEnabled = true
                    hookContact.physicsBody?.contactTestBitMask = GoldenCategory
                    self.isContact = false
                    if self.numberPosition == 1{
                        self.numberOneLabel.text = "\(self.addCurrentNumber)"
                        self.addNumberOne = self.addCurrentNumber
                        if self.addNumberOne == self.numberArray[self.numberPosition - 1 + 2*(self.currentLevel-1)] || self.addNumberOne == self.numberArray[self.numberPosition - 1 + 2*(self.currentLevel-1) + 1] {
                            self.numberPosition += 1
                        }else{
                            //计算错误执行的操作
                            self.lives -= 1
                            if self.lives == 0{
                                PlaygroundPage.current.assessmentStatus = .fail(hints: ["👻很遗憾你没有通过这个关卡，点击运行我的代码按钮试一次把，加油💪"], solution: nil)
                                print("fail")
                                for all in self.children{
                                    all.removeAllActions()
                                }
                                self.isUserInteractionEnabled = false
                                self.person.personLose()
                                playSoundEffect(fileName: "answerError.wav", loops: 0)
                                self.numberOneLabel.text = " "
                                //第二三个空都是哭脸
                                self.numberTwoLabel.fontColor = UIColor.white
                                self.numberTwoLabel.text = "☹️"
                                self.numberThreeLabel.fontColor = UIColor.white
                                self.numberThreeLabel.text = "☹️"
                            }else {
                                //鱼钩错之后添加一条鱼
                                for i in 0...3{
                                    if self.addNumberOne == self.numberArray[i]{
                                        self.fish = GoldenNode.NewInstance(tag: self.addNumberOne)
                                        let fishAddX = self.size.width + self.fish.size.width/2
                                        let fishAddY = CGFloat.random(min: self.fish.size.height/2,max: self.size.height/2 - self.fish.size.height)
                                        let fishSpeed = CGFloat.random(min: 4.0,max: 6.0)
                                        self.fish.position = CGPoint(x: fishAddX, y: fishAddY)
                                        self.fish.moveRepeat(size: self.size, tag: self.addNumberOne, speed : fishSpeed)
                                        self.addChild(self.fish)
                                    }
                                }
                                playSoundEffect(fileName: "answerError.wav", loops: 0)
                                self.numberOneLabel.fontColor = UIColor.red
                                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                                    self.numberOneLabel.text = " "
                                    self.numberTwoLabel.text = " "
                                    self.numberOneLabel.fontColor = UIColor.white
                                    self.numberTwoLabel.fontColor = UIColor.white
                                    self.numberPosition = 1
                                    self.addNumberOne = 0
                                    self.addNumberTwo = 0
                                }
                            }
                        }
                    }else if self.numberPosition == 2 {
                        self.numberTwoLabel.text = "\(self.addCurrentNumber)"
                        self.addNumberTwo = self.addCurrentNumber
                        self.numberPosition -= 1
                        if (self.addNumberOne * self.addNumberTwo) == self.numberThree{
                            print("success")
                            playSoundEffect(fileName: "coin1.wav", loops: 0)
                            self.numberOneLabel.fontColor = UIColor.green
                            self.numberTwoLabel.fontColor = UIColor.green
                            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                                self.currentLevel += 1
                                self.numberOneLabel.text = " "
                                self.numberTwoLabel.text = " "
                                self.numberOneLabel.fontColor = UIColor.white
                                self.numberTwoLabel.fontColor = UIColor.white
                                switch self.currentLevel {
                                case 1:
                                    self.numberThree = 8
                                case 2:
                                    self.numberThree = 24
                                case 3:
                                    //成功的人动画
                                    for all in self.children{
                                        all.removeAllActions()
                                    }
                                    self.isUserInteractionEnabled = false
                                    self.person.personWin()
                                    playSoundEffect(fileName: "laugh.wav", loops: 0)
                                    PlaygroundPage.current.assessmentStatus = .pass(message: "**恭喜🎉** 你已经掌握了乘法运算的逆向计算! 点击[下一关](@next)进入除法运算的逆向计算")
                                    self.numberOneLabel.text = " "
                                    self.numberTwoLabel.text = " "
                                    self.numberThreeLabel.fontColor = UIColor.white
                                    self.numberThreeLabel.text = "🙂"
                                default:
                                    print("a")
                                }
                                self.numberThreeLabel.text = "\(self.numberThree)"
                            }
                        }else {
                            self.lives -= 1
                            if self.lives == 0{
                                PlaygroundPage.current.assessmentStatus = .fail(hints: ["👻很遗憾你没有通过这个关卡，点击运行我的代码按钮试一次把，加油💪"], solution: nil)
                                print("fail")
                                for all in self.children{
                                    all.removeAllActions()
                                }
                                self.isUserInteractionEnabled = false
                                self.person.personLose()
                                playSoundEffect(fileName: "answerError.wav", loops: 0)
                                self.numberOneLabel.text = " "
                                self.numberTwoLabel.text = " "
                                self.numberThreeLabel.fontColor = UIColor.white
                                self.numberThreeLabel.text = "☹️"
                            }else {
                                //鱼钩错之后添加一条鱼
                                for i in 0...3{
                                    if self.addNumberOne == self.numberArray[i]{
                                        self.fish =                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  GoldenNode.NewInstance(tag: self.addNumberOne)
                                        let fishAddX = self.size.width + self.fish.size.width/2
                                        let fishAddY = CGFloat.random(min: self.fish.size.height/2,max: self.size.height/2 - self.fish.size.height)
                                        let fishSpeed = CGFloat.random(min: 4.0,max: 6.0)
                                        self.fish.position = CGPoint(x: fishAddX, y: fishAddY)
                                        self.fish.moveRepeat(size: self.size, tag: self.addNumberOne, speed : fishSpeed)
                                        self.addChild(self.fish)
                                    }
                                    if self.addNumberTwo == self.numberArray[i]{
                                        self.fish = GoldenNode.NewInstance(tag: self.addNumberTwo)
                                        let fishAddX = self.size.width + self.fish.size.width/2
                                        let fishAddY = CGFloat.random(min: self.fish.size.height/2,max: self.size.height/2 - self.fish.size.height)
                                        let fishSpeed = CGFloat.random(min: 2.0,max: 5.0)
                                        self.fish.position = CGPoint(x: fishAddX, y: fishAddY)
                                        self.fish.moveRepeat(size: self.size, tag: self.addNumberTwo, speed : fishSpeed)
                                        self.addChild(self.fish)
                                    }
                                }
                                playSoundEffect(fileName: "answerError.wav", loops: 0)
                                self.numberOneLabel.fontColor = UIColor.red
                                self.numberTwoLabel.fontColor = UIColor.red
                                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                                    self.numberOneLabel.text = " "
                                    self.numberTwoLabel.text = " "
                                    self.numberOneLabel.fontColor = UIColor.white
                                    self.numberTwoLabel.fontColor = UIColor.white
                                    self.numberPosition = 1
                                    self.addNumberOne = 0
                                    self.addNumberTwo = 0
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override public func update(_ currentTime: TimeInterval) {
        livesLabel.text = "\(lives)"
    }
}
