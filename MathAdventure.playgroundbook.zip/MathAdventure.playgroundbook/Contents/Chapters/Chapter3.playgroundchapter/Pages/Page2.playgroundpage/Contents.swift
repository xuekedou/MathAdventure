/*:
 🎉 非常棒，你现在已经完全掌握了加法运算符！
 # 目标：给出减法等式右边的结果，通过钓鱼的方式找出等式左边的两个数值使等式成立！
 * 只有减法等式左边的两个数值都正确并且[顺序也正确](glossary://顺序也正确)，等式才能成立。
 * 你可以自定义[容错次数](glossary://容错次数)来调整关卡的难度哦~
 
 # 🎉 非常棒，接下来的关卡你将会完成乘法的逆向运算。
 */
//#-hidden-code
import UIKit
import SpriteKit
import GameplayKit
import PlaygroundSupport


let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let scene = GameSceneTen(size: CGSize(width: 320, height: 480))
scene.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
scene.physicsBody = SKPhysicsBody(edgeLoopFrom: scene.frame)
sceneView.presentScene(scene)

PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
//自定义容错次数
//#-code-completion(everything, hide)
scene.lives = /*#-editable-code*/2/*#-end-editable-code*/
//#-hidden-code
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code

