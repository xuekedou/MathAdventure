/*:
 🎉 非常棒，你现在已经掌握了加减乘除四个数学运算符！
 # 目标：给出等式右边的结果，通过钓鱼的方式找出等式左边的两个数值使等式成立！
 * 只有加法等式左边的[两个数值都正确](glossary://两个数值都正确)，等式才能成立。
 * 每个关卡有两个等式，找出两个等式左边的两个数值之后即可进入下一个关卡。
 * 你可以自定义[容错次数](glossary://容错次数)来调整关卡的难度哦~
 
 # 🎉 非常棒，你现在了解了这个章节游戏的基本规则，继续你的数学之旅吧！
 */
//#-hidden-code
import UIKit
import SpriteKit
import GameplayKit
import PlaygroundSupport


let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let scene = GameSceneNine(size: CGSize(width: 320, height: 480))
scene.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
scene.physicsBody = SKPhysicsBody(edgeLoopFrom: scene.frame)
sceneView.presentScene(scene)

PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
//自定义容错次数
//#-code-completion(everything, hide)
scene.lives = /*#-editable-code*/2/*#-end-editable-code*/
//#-hidden-code
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
