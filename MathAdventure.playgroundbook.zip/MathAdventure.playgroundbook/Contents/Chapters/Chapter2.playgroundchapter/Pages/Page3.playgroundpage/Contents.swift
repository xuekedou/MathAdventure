/*:
 🎉 非常棒，你已经掌握了加法运算符和减法运算符！
 # 目标：自定义乘法等式左边的数值，通过钓鱼的方式找出等式右边的数值
 * 通过左边的代码编写区域自定义等式左边的数值。[注：等式右边的数值不小于1且不超过50！](glossary://注：等式右边的数值不小于1且不超过50！)
 
 🎉 非常棒，在下一个关卡中你将自定义除法运算等式！
 */
//#-hidden-code
import UIKit
import SpriteKit
import GameplayKit
import PlaygroundSupport
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let scene = GameSceneSeven(size: CGSize(width: 320, height: 480))
scene.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
scene.physicsBody = SKPhysicsBody(edgeLoopFrom: scene.frame)
sceneView.presentScene(scene)

PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
//#-code-completion(everything, hide)
//自定义第一个乘法等式左边的两个数值
scene.firstNumberOfFirstLevel = /*#-editable-code*/3/*#-end-editable-code*/
scene.secondNumberOfFirstLevel = /*#-editable-code*/1/*#-end-editable-code*/
//自定义第二个乘法等式左边的两个数值
scene.firstNumberOfSecondLevel = /*#-editable-code*/4/*#-end-editable-code*/
scene.secondNumberOfSecondLevel = /*#-editable-code*/5/*#-end-editable-code*/
//自定义第三个乘法等式左边的两个数值
scene.firstNumberOfThirdLevel = /*#-editable-code*/7/*#-end-editable-code*/
scene.secondNumberOfThirdLevel = /*#-editable-code*/3/*#-end-editable-code*/
//自定义容错次数
scene.lives = /*#-editable-code*/2/*#-end-editable-code*/
//#-hidden-code
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
