/*:
 🎉 非常棒，通过前面的章节，你已经认识了加减乘除，在这个章节中，你将进一步掌握它们！
 # 目标：自定义等式左边的数值，通过钓鱼的方式找出等式右边的数值
 * 通过左边的代码编写区域自定义等式左边的数值。[注：等式右边的数值不超过50！](glossary://注：等式右边的数值不超过50！)

 🎉 非常棒，你现在了解了本章节游戏的基本规则，继续你的数学之旅吧！
 */
//#-hidden-code
import UIKit
import SpriteKit
import GameplayKit
import PlaygroundSupport

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let scene = GameSceneFive(size: CGSize(width: 320, height: 480))
scene.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
scene.physicsBody = SKPhysicsBody(edgeLoopFrom: scene.frame)
sceneView.presentScene(scene)

PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code
//#-code-completion(everything, hide)
//自定义第一个加法等式左边的两个数值
scene.firstNumberOfFirstLevel = /*#-editable-code*/1/*#-end-editable-code*/
scene.secondNumberOfFirstLevel = /*#-editable-code*/3/*#-end-editable-code*/
//自定义第二个加法等式左边的两个数值
scene.firstNumberOfSecondLevel = /*#-editable-code*/3/*#-end-editable-code*/
scene.secondNumberOfSecondLevel = /*#-editable-code*/4/*#-end-editable-code*/
//自定义第三个加法等式左边的两个数值
scene.firstNumberOfThirdLevel = /*#-editable-code*/4/*#-end-editable-code*/
scene.secondNumberOfThirdLevel = /*#-editable-code*/5/*#-end-editable-code*/
//自定义容错次数
scene.lives = /*#-editable-code*/2/*#-end-editable-code*/

//#-hidden-code
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code

