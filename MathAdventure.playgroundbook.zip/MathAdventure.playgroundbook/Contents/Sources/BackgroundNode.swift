//
//  BackgroundNode.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/10.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit

public class BackgroundNode : SKNode {
    
    public func setup(size : CGSize) {
        let yPos : CGFloat = size.height * 0.50
        let startPoint = CGPoint(x: -100, y: yPos)
        let endPoint = CGPoint(x: size.width+100, y: yPos)
        physicsBody = SKPhysicsBody(edgeFrom: startPoint, to: endPoint)
        physicsBody?.restitution = 0.0
        
        physicsBody?.categoryBitMask = FloorCategory
        physicsBody?.contactTestBitMask = 0
        physicsBody?.collisionBitMask = 0
        
        let skyTexture = SKTexture(imageNamed: "bg")
        let skyNode = SKSpriteNode(texture: skyTexture, size: size)
        skyNode.anchorPoint = CGPoint(x: 0, y: 0)
        skyNode.physicsBody?.isDynamic = false
        skyNode.zPosition = 0
        
        
        var textures:[SKTexture] = []
        for i in 2...5 {
            textures.append(SKTexture(imageNamed: "hai\(i)"))
        }
//        textures.append(textures[1])
        let ocAnimation = SKAction.animate(with: textures,
                                           timePerFrame: 0.5)
        let groundSize = CGSize(width: size.width, height: size.height * 0.55)
        let groundTexture = SKTexture(imageNamed: "hai2")
        let groundNode = SKSpriteNode(texture: groundTexture, size: groundSize)
        groundNode.anchorPoint = CGPoint(x: 0, y: 0)
        groundNode.physicsBody?.isDynamic = false
        groundNode.zPosition = 1
        groundNode.run(SKAction.repeatForever(ocAnimation))
        
        addChild(skyNode)
        addChild(groundNode)
    }
}
