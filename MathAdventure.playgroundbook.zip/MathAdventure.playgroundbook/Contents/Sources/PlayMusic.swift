//
//  PlayMusic.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/18.
//  Copyright © 2017年 xsf. All rights reserved.
//

import Foundation
import AVFoundation

var backgroundMusicPlayer : AVAudioPlayer!
var SoundEffectPlayer : AVAudioPlayer!
public func playBackgroundMusic(fileName:String,loops:Int){
    let resourceUrl = Bundle.main.url(forResource: fileName, withExtension: nil)
    guard let url = resourceUrl else {
        print("Could not find file: \(fileName)")
        return
    }
    do {
        try backgroundMusicPlayer = AVAudioPlayer(contentsOf: url)
        backgroundMusicPlayer.numberOfLoops = loops
        backgroundMusicPlayer.volume = 0.2
        backgroundMusicPlayer.prepareToPlay()
        backgroundMusicPlayer.play()
    }catch {
        print("Could not create audio player!")
        return
    }
}

public func playSoundEffect(fileName:String,loops:Int){
    let resourceUrl = Bundle.main.url(forResource: fileName, withExtension: nil)
    guard let url = resourceUrl else {
        print("Could not find file: \(fileName)")
        return
    }
    do {
        try SoundEffectPlayer = AVAudioPlayer(contentsOf: url)
        SoundEffectPlayer.numberOfLoops = loops
        
        SoundEffectPlayer.prepareToPlay()
        SoundEffectPlayer.play()
    }catch {
        print("Could not create audio player!")
        return
    }
}
