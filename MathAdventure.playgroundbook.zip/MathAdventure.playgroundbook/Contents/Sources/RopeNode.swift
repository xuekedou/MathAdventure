//
//  RopeNode.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/10.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit

public class RopeNode : SKSpriteNode{
    public static func newInstance() -> RopeNode{
        var Rope = RopeNode(imageNamed: "rope")
        let rateWidth = 0.1
        let rateHeight = 0.2
        let ropeWidth = Rope.size.width * CGFloat(rateWidth)
        let ropeHeight = Rope.size.height * CGFloat(rateHeight)
        let ropeSize = CGSize(width: ropeWidth, height: ropeHeight)
        Rope.size = ropeSize
        Rope.physicsBody = SKPhysicsBody(texture: Rope.texture!, size: Rope.size)
        Rope.physicsBody?.affectedByGravity = false
        Rope.physicsBody?.categoryBitMask = RopeCategory
        Rope.physicsBody?.collisionBitMask = 0
        Rope.physicsBody?.contactTestBitMask = 0
        Rope.zPosition = 2
        Rope.name = "rope"
        return Rope
        
    }
    public func moveDownY(offset : CGFloat,time : Double = 1.0)->SKAction{
        let action = SKAction.moveTo(y: offset, duration: time)
        return action
    }
    public func moveUpY(offset : CGFloat,time : Double)->SKAction{
        let action = SKAction.moveTo(y: offset, duration: time)
        return action
    }
    public func moveX(offset : CGFloat)->SKAction{
        let action = SKAction.moveBy(x: offset, y: 0, duration: 1.0)
        return action
    }
    public func addToDown(sonNode : SKSpriteNode){
        let position = CGPoint(x: 0, y: 0)
        addChild(sonNode)
        sonNode.position = position
    }
    
}
