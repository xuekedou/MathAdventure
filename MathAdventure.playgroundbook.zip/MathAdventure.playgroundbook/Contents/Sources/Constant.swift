//
//  Constant.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/10.
//  Copyright © 2017年 xsf. All rights reserved.
//

import Foundation
import SpriteKit

public let WorldCategory    : UInt32 = 0x1 << 1//1
public let GoldenCategory : UInt32 = 0x1 << 2//2
public let FloorCategory    : UInt32 = 0x1 << 3//4
public let PersonCategory : UInt32 = 0x1 << 4//8
public let RopeCategory : UInt32 = 0x1 << 5//16
public let HookCategory : UInt32 = 0x1 << 7//64

extension CGFloat {
    static public func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / Float(UInt32.max))
    }
    static public func random(min: CGFloat, max: CGFloat) -> CGFloat {
        assert(min < max)
        return CGFloat.random() * (max - min) + min
    }
}
