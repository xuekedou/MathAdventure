//
//  PersonNode.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/10.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit

public class PersonNode : SKSpriteNode {
    public static func NewInstance() -> PersonNode{
        let person = PersonNode(imageNamed: "person1")
        let rate = 0.3
        let personWidth = person.size.width * CGFloat(rate)
        let personHeight = person.size.height * CGFloat(rate)
        let personSize = CGSize(width: personWidth, height: personHeight)
        person.size = personSize
        person.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: personSize.width, height: personSize.height/4*3))
        person.physicsBody?.affectedByGravity = false
        person.physicsBody?.categoryBitMask = PersonCategory
        person.physicsBody?.collisionBitMask = 0
        person.physicsBody?.contactTestBitMask = 0
        person.name = "person"
        person.zPosition = 2
        
        var textures:[SKTexture] = []
        for i in 1...3 {
            textures.append(SKTexture(imageNamed: "person\(i)"))
        }
        //        textures.append(textures[1])
        let ocAnimation = SKAction.animate(with: textures,
                                           timePerFrame: 0.4)
        person.run(SKAction.repeatForever(ocAnimation))
        return person
    }
    public func move(offset : CGFloat)->SKAction{
        let action = SKAction.moveBy(x: offset, y: 0, duration: 1.0)
        return action
    }
    public func moveRepeat(size : CGSize){
        let actionLeftMove = SKAction.moveTo(x: self.frame.width/2, duration: 3.0)
        let actionRightMove = SKAction.moveTo(x: size.width - self.frame.width/2, duration: 3.0)
        let sequence = SKAction.repeatForever(SKAction.sequence([actionLeftMove,actionRightMove]))
        self.run(sequence)
    }
    public func personWin(){
        let winOne = SKTexture(imageNamed: "person1")
        let winTwo = SKTexture(imageNamed: "personWin")
        var texturesWin:[SKTexture] = [winOne,winTwo]
        let winAnimation = SKAction.animate(with: texturesWin,
                                            timePerFrame: 0.4)
        self.run(SKAction.repeatForever(winAnimation))
    }
    public func personLose(){
        let loseOne = SKTexture(imageNamed: "personWin")
        let loseTwo = SKTexture(imageNamed: "personLose")
        var texturesLose:[SKTexture] = [loseOne,loseTwo]
        let loseAnimation = SKAction.animate(with: texturesLose,
                                            timePerFrame: 0.4)
        self.run(SKAction.repeatForever(loseAnimation))
    }
    
}
