//
//  HookNode.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/23.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit

public class HookNode : SKSpriteNode{
    public static func newInstance() -> HookNode{
        var Hook = HookNode(imageNamed: "hook")
        let rate = 0.2
        let hookWidth = Hook.size.width * CGFloat(rate)
        let hookHeight = Hook.size.height * CGFloat(rate)
        let hookSize = CGSize(width: hookWidth, height: hookHeight)
        Hook.size = hookSize
        Hook.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 3, height: 3), center: CGPoint(x: Hook.size.width/2 - 1.5, y: 0))
        Hook.physicsBody?.affectedByGravity = false
        Hook.physicsBody?.categoryBitMask = HookCategory
        Hook.physicsBody?.collisionBitMask = 0
        Hook.physicsBody?.contactTestBitMask = GoldenCategory
        Hook.zPosition = 2
        Hook.name = "hook"
        return Hook
    }
}

