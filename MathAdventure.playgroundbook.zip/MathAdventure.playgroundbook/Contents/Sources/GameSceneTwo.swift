//
//  GameSceneTwo.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/19.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit
import GameplayKit

public class GameSceneTwo: SKScene,SKPhysicsContactDelegate {
    
    let background = BackgroundNode()
    let person = PersonNode.NewInstance()
    let rope = RopeNode.newInstance()
    var cropNode = SKCropNode()
    var maskNode = SKSpriteNode()
    var fish : GoldenNode!
    var addNumber : Int = 0
    var numberOneLabel : SKLabelNode!
    var operatOneLabel : SKLabelNode!
    var numberTwoLabel : SKLabelNode!
    var operatTwoLabel : SKLabelNode!
    var numberThreeLabel : SKLabelNode!
    var resultDefine : SKLabelNode!
    var livesLabel : SKLabelNode!
    var lives : Int = 2
    var resultCalculate : Int!
    
    override public func didMove(to view: SKView) {
        super.didMove(to: view)
        //        playBackgroundMusic(fileName: "background.wav", loops: -1)
        //背景
        background.setup(size: size)
        addChild(background)
        //人
        person.position = CGPoint(x: size.width/2, y: size.height/2 + person.size.height/8*3)
        addChild(person)
        rope.position.x = person.frame.size.width/6
        rope.position.y = person.frame.height/4
        maskNode = SKSpriteNode(color: .white, size: CGSize(width: size.width, height: size.height/2 + person.size.height/7*2))
        maskNode.anchorPoint = CGPoint(x: 0.5, y: 0)
        maskNode.position = CGPoint(x: 0, y: -(person.frame.size.height/8*3 + size.height/2))
        maskNode.zPosition = 2
        cropNode.maskNode = maskNode
        cropNode.addChild(rope)
        cropNode.name = "crop"
        cropNode.zPosition = 2
        //        addChild(cropNode)
        //        person.addChild(maskNode)
        person.addChild(cropNode)
        person.moveRepeat(size: size)
        spawnFishes()
        setOperate()
    }
    func setOperate(){
        //第一个数字
        numberOneLabel = SKLabelNode()
        numberOneLabel.text = "1"
        numberOneLabel.position = CGPoint(x: 10, y: size.height/8*7)
        numberOneLabel.physicsBody?.isDynamic = false
        numberOneLabel.zPosition = 10
        numberOneLabel.fontColor = UIColor.white
        addChild(numberOneLabel)
        //第一个运算符
        operatOneLabel = SKLabelNode()
        operatOneLabel.text = "+"
        operatOneLabel.position = CGPoint(x: numberOneLabel.frame.maxX + 10, y: size.height/8*7)
        operatOneLabel.physicsBody?.isDynamic = false
        operatOneLabel.zPosition = 10
        operatOneLabel.fontColor = UIColor.white
        addChild(operatOneLabel)
        //第二个数字
        numberTwoLabel = SKLabelNode()
        numberTwoLabel.text = "2"
        numberTwoLabel.position = CGPoint(x: operatOneLabel.frame.maxX + 10 , y: size.height/8*7)
        numberTwoLabel.physicsBody?.isDynamic = false
        numberTwoLabel.zPosition = 10
        numberTwoLabel.fontColor = UIColor.white
        addChild(numberTwoLabel)
        //第一个运算符
        operatTwoLabel = SKLabelNode()
        operatTwoLabel.text = "="
        operatTwoLabel.position = CGPoint(x: numberTwoLabel.frame.maxX + 10, y: size.height/8*7)
        operatTwoLabel.physicsBody?.isDynamic = false
        operatTwoLabel.zPosition = 10
        operatTwoLabel.fontColor = UIColor.white
        addChild(operatTwoLabel)
        //结果label
        numberThreeLabel = SKLabelNode()
        numberThreeLabel.text = " "
        numberThreeLabel.position = CGPoint(x: operatTwoLabel.frame.maxX + 10, y: size.height/8*7)
        numberThreeLabel.physicsBody?.isDynamic = false
        numberThreeLabel.zPosition = 10
        numberThreeLabel.fontColor = UIColor.white
        addChild(numberThreeLabel)
        //结果判断的label
        resultDefine = SKLabelNode()
        resultDefine.text = " "
        resultDefine.position = CGPoint(x: numberThreeLabel.frame.maxX + 100, y: size.height/8*7)
        resultDefine.fontColor = UIColor.red
        resultDefine.physicsBody?.isDynamic = false
        resultDefine.zPosition = 10
        addChild(resultDefine)
        //剩余生命次数
        livesLabel = SKLabelNode()
        livesLabel.text = "\(lives)"
        livesLabel.position = CGPoint(x: size.width - 50, y: size.height/8*7)
        livesLabel.fontColor = UIColor.white
        livesLabel.physicsBody?.isDynamic = false
        livesLabel.zPosition = 10
        addChild(livesLabel)
    }
    override public func sceneDidLoad() {
        self.physicsWorld.contactDelegate = self
    }
    func spawnFishes(){
        //填入数字的计算结果
        resultCalculate = (Int(numberOneLabel.text!))! + (Int(numberTwoLabel.text!))!
        
        for i in 1...4{
            fish = GoldenNode.NewInstance(tag: i)
            fish.position = CGPoint(x: CGFloat(10 + 100*(i-1)), y: size.height/10 * CGFloat(i))
            fish.moveRepeat(size: size, tag: i, speed : 5.0)
            addChild(fish)
        }
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let position = touch?.location(in: self)
        let node = self.nodes(at: position!).first
        let name = node?.name
        let index = name?.index((name?.startIndex)!, offsetBy: 4)
        let prefix = name?.substring(to: index!)
        if  name == "person"{
            //            isUserInteractionEnabled = false
            print("person")
            //            let Y = rope.moveY(offset: -(person.frame.size.height/8*3 + size.height/2)+rope.size.height/2)
            let Y = rope.moveDownY(offset: -(person.frame.size.height/8*3 + size.height/2)+rope.size.height/2)
            //            let Y1 = rope.moveY(offset: -(person.frame.size.width/2 + 20)+rope.size.height/2)
            let Y1 = rope.moveUpY(offset: -(person.frame.size.width/2 + 20)+rope.size.height/2, time: 1.0)
            rope.run(Y){
                self.rope.run(Y1)
            }
        }else if prefix == "fish"{
            
        }
    }
    public func didBegin(_ contact: SKPhysicsContact) {
        if (contact.bodyA.categoryBitMask == RopeCategory && contact.bodyB.categoryBitMask == GoldenCategory) {
            let fishRemove = contact.bodyB.node!
            let fishID = fishRemove.name
            if fishID == "fish1"{
                addNumber = 1
            }else if fishID == "fish2"{
                addNumber = 2
            }else if fishID == "fish3"{
                addNumber = 3
            }else if fishID == "fish4"{
                addNumber = 4
            }else if fishID == "fish5"{
                addNumber = 5
            }else if fishID == "fish6"{
                addNumber = 6
            }
            fishRemove.physicsBody?.contactTestBitMask = 0
            rope.physicsBody?.contactTestBitMask = 0
            rope.removeAllActions()
            fishRemove.removeAllActions()
            fishRemove.removeFromParent()
            rope.addChild(fishRemove)
            fishRemove.position = CGPoint(x: 0, y: -rope.size.height/2)
            print("c")
            let ropeReset = rope.moveUpY(offset: person.frame.height/4, time: 1)
            rope.run(ropeReset){
                fishRemove.removeFromParent()
                self.rope.physicsBody?.contactTestBitMask = GoldenCategory
                self.rope.physicsBody?.categoryBitMask = RopeCategory
                self.numberThreeLabel.text = "\(self.addNumber)"
                //判断是否有正确
                if self.addNumber == 3{
                    print("success")
                    self.resultDefine.text = "答案正确！"
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
//                        let winScene = WinScene(size: self.size)
//                        self.view?.presentScene(winScene)
                    }
                }else {
                    self.lives -= 1
                    if self.lives == 0{
                        let loseScene = LoseScene(size: self.size)
                        self.view?.presentScene(loseScene)
                        print("fail")
                    }else {
                        self.resultDefine.text = "答案错误！"
                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                            self.resultDefine.text = " "
                            self.numberThreeLabel.text = " "
                        }
                    }
                }
            }
        }
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override public func update(_ currentTime: TimeInterval) {
        
    }
}


