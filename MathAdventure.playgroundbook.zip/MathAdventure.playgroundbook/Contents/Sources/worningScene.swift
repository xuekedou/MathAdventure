//
//  WinScene.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/19.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit
import GameplayKit

public class WorningScene : SKScene {
    var WorningNode : SKSpriteNode!
    override public func didMove(to view: SKView) {
        super.didMove(to: view)
        backgroundColor = UIColor.white
        WorningNode = SKSpriteNode()
        WorningNode = SKSpriteNode(texture: SKTexture(imageNamed: "numberOut"))
        WorningNode.physicsBody?.isDynamic = false
        let rate = 0.5
        let width = WorningNode.size.width * CGFloat(rate)
        let height = WorningNode.size.height * CGFloat(rate)
        let celeSize = CGSize(width: width, height: height)
        WorningNode.position = CGPoint(x: size.width/2, y: size.height/2)
        WorningNode.size = celeSize
        addChild(WorningNode)
    }
}
