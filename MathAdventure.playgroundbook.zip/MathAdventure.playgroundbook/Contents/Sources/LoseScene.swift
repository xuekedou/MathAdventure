//
//  LoseScene.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/19.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit
import GameplayKit

public class LoseScene : SKScene {
    var background : SKLabelNode!
    override public func didMove(to view: SKView) {
        super.didMove(to: view)
        background = SKLabelNode(text: "很遗憾，你钓错了鱼！")
        background.position = CGPoint(x: size.width/2, y: size.height/2)
        addChild(background)
    }
}
