//
//  GoldenNode.swift
//  MathAdvanture
//
//  Created by xsf on 2017/10/10.
//  Copyright © 2017年 xsf. All rights reserved.
//

import SpriteKit

public class GoldenNode : SKSpriteNode{
    public static func NewInstance(tag : Int)->GoldenNode{
        let golden = GoldenNode(imageNamed: "\(tag)")
        let rate = 0.3
        let goldenWidth = golden.size.width * CGFloat(rate)
        let goldenHeight = golden.size.height * CGFloat(rate)
        let goldenSize = CGSize(width: goldenWidth, height: goldenHeight)
        golden.size = goldenSize
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: -golden.size.height / 3))
        path.addLine(to: CGPoint(x: -golden.size.width / 3, y: 0))
        path.addLine(to: CGPoint(x: 0, y: golden.size.height / 3))
        path.addLine(to: CGPoint(x: golden.size.width / 3, y: 0))
        golden.physicsBody = SKPhysicsBody(polygonFrom: path.cgPath)
        
        golden.physicsBody?.affectedByGravity = false
        golden.physicsBody?.categoryBitMask = GoldenCategory
        golden.physicsBody?.collisionBitMask = 0
        golden.physicsBody?.contactTestBitMask = 0
        golden.name = "\(tag)"
        golden.zPosition = 2
        return golden
    }
    public func moveRepeat(size : CGSize,tag : Int,speed : CGFloat){
        let actionLeftMove = SKAction.moveTo(x: -self.frame.width/2, duration: Double(speed))
        let turnRight = SKAction.setTexture(SKTexture(imageNamed: "\(tag)y"))
        let actionRightMove = SKAction.moveTo(x: size.width + self.frame.width/2, duration: Double(speed))
        let turnLeft = SKAction.setTexture(SKTexture(imageNamed: "\(tag)"))
        let sequence = SKAction.repeatForever(SKAction.sequence([actionLeftMove,turnRight,actionRightMove,turnLeft]))
        self.run(sequence)
        
    }
    
}

